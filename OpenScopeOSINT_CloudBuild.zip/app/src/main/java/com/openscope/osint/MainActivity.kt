package com.openscope.osint

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.i18n.phonenumbers.PhoneNumberUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151E32)
private val Accent = Color(0xFF69E0C0)
private val Muted = Color(0xFF9AA8C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OpenScopeApp() }
    }
}

data class Finding(val title: String, val detail: String, val status: String = "INFO")
data class Report(val heading: String, val findings: List<Finding>, val created: String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))

private suspend fun request(url: String): String = withContext(Dispatchers.IO) {
    val conn = (URL(url).openConnection() as HttpURLConnection)
    conn.connectTimeout = 9000
    conn.readTimeout = 9000
    conn.setRequestProperty("User-Agent", "OpenScopeOSINT/1.0 (public-source research)")
    conn.requestMethod = "GET"
    try {
        val code = conn.responseCode
        val stream = if (code in 200..399) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..399) throw Exception("HTTP $code")
        body
    } finally { conn.disconnect() }
}

private fun safeDomain(raw: String): String {
    var s = raw.trim().lowercase().removePrefix("https://").removePrefix("http://").substringBefore("/")
    require(s.isNotBlank() && s.length <= 253 && s.matches(Regex("[a-z0-9.-]+")) && "." in s) { "Введите корректный домен, например example.com" }
    return s
}

private suspend fun usernameLookup(raw: String): List<Finding> {
    val user = raw.trim().removePrefix("@")
    require(user.matches(Regex("[A-Za-z0-9._-]{2,30}"))) { "Ник должен содержать 2–30 символов: латиница, цифры, . _ -" }
    val sites = listOf(
        "GitHub" to "https://github.com/$user",
        "Reddit" to "https://www.reddit.com/user/$user/",
        "TikTok" to "https://www.tiktok.com/@$user",
        "Instagram" to "https://www.instagram.com/$user/",
        "X" to "https://x.com/$user",
        "Pinterest" to "https://www.pinterest.com/$user/",
        "Twitch" to "https://www.twitch.tv/$user"
    )
    return sites.map { (name, link) ->
        try {
            val body = request(link)
            val existsHint = body.isNotBlank() && !body.contains("Page Not Found", true) && !body.contains("Sorry, this page", true)
            Finding(name, "$link\nОтвет сайта получен. Наличие профиля не подтверждено окончательно.", if (existsHint) "CHECK" else "UNKNOWN")
        } catch (e: Exception) {
            Finding(name, "$link\nСайт не подтвердил профиль: ${e.message ?: "ошибка сети"}.", "UNKNOWN")
        }
    }
}

private suspend fun emailLookup(raw: String): List<Finding> {
    val email = raw.trim()
    require(email.matches(Regex("^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$"))) { "Некорректный формат email" }
    val domain = email.substringAfter("@")
    val encoded = URLEncoder.encode(domain, "UTF-8")
    val json = JSONObject(request("https://dns.google/resolve?name=$encoded&type=MX"))
    val answers = json.optJSONArray("Answer")
    val mx = mutableListOf<String>()
    if (answers != null) for (i in 0 until answers.length()) mx.add(answers.getJSONObject(i).optString("data"))
    return listOf(
        Finding("Формат", "Адрес соответствует базовой проверке синтаксиса.", "OK"),
        Finding("Домен", domain, "INFO"),
        Finding("MX-записи", if (mx.isEmpty()) "MX не найдены или DNS-ответ недоступен." else mx.joinToString("\n"), if (mx.isEmpty()) "WARN" else "OK"),
        Finding("Ограничение", "Это не подтверждает существование почтового ящика и не выполняет вход или отправку писем.", "INFO")
    )
}

private fun phoneLookup(raw: String, region: String): List<Finding> {
    val util = PhoneNumberUtil.getInstance()
    val number = util.parse(raw.trim(), region.uppercase())
    val valid = util.isValidNumber(number)
    val formatted = util.format(number, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL)
    val type = util.getNumberType(number).name
    return listOf(
        Finding("Номер", formatted, if (valid) "OK" else "WARN"),
        Finding("Страна", util.getRegionCodeForNumber(number) ?: "Не определена", "INFO"),
        Finding("Тип номера", type, "INFO"),
        Finding("Важно", "Оператор и владелец не определяются достоверно: переносимость номеров и ограничения баз делают такие сведения ненадёжными.", "INFO")
    )
}

private suspend fun domainLookup(raw: String): List<Finding> {
    val domain = safeDomain(raw)
    val encoded = URLEncoder.encode(domain, "UTF-8")
    val dns = JSONObject(request("https://dns.google/resolve?name=$encoded&type=A"))
    val arr = dns.optJSONArray("Answer")
    val ips = mutableListOf<String>()
    if (arr != null) for (i in 0 until arr.length()) {
        val a = arr.getJSONObject(i)
        if (a.optInt("type") == 1) ips.add(a.optString("data"))
    }
    val rdap = try { JSONObject(request("https://rdap.org/domain/$encoded")) } catch (_: Exception) { JSONObject() }
    val registrar = rdap.optJSONObject("entities")?.optString("handle").orEmpty()
    val out = mutableListOf(
        Finding("Домен", domain, "OK"),
        Finding("A-записи", if (ips.isEmpty()) "Не найдены" else ips.distinct().joinToString(), if (ips.isEmpty()) "WARN" else "OK"),
        Finding("RDAP", if (rdap.has("ldhName")) "Ответ RDAP получен для ${rdap.optString("ldhName")}" else "Регистрационные данные недоступны", "INFO")
    )
    ips.distinct().take(3).forEach { ip ->
        try {
            val info = JSONObject(request("https://ipwho.is/$ip"))
            out.add(Finding("IP $ip", "Страна: ${info.optString("country")}\nРегион: ${info.optString("region")}\nГород: ${info.optString("city")}\nОрганизация: ${info.optJSONObject("connection")?.optString("org") ?: "н/д"}", "INFO"))
        } catch (e: Exception) { out.add(Finding("IP $ip", "Геоданные недоступны: ${e.message}", "WARN")) }
    }
    return out
}

@Composable
fun OpenScopeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("RU") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var report by remember { mutableStateOf<Report?>(null) }
    val tabs = listOf("Ник", "Email", "Телефон", "Сайт / IP", "Соцсети")
    val hint = when (tab) {
        0 -> "@username"
        1 -> "name@example.com"
        2 -> "+7 900 000-00-00"
        3 -> "example.com"
        else -> "Публичные профили и ссылки"
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, onPrimary = Bg,
        onBackground = Color.White, onSurface = Color.White, secondary = Muted
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == 0, onClick = { tab=0 }, icon={ Icon(Icons.Default.PersonSearch, null) }, label={ Text("Ник") })
                NavigationBarItem(selected = tab == 1, onClick = { tab=1 }, icon={ Icon(Icons.Default.Mail, null) }, label={ Text("Email") })
                NavigationBarItem(selected = tab == 2, onClick = { tab=2 }, icon={ Icon(Icons.Default.Phone, null) }, label={ Text("Телефон") })
                NavigationBarItem(selected = tab == 3, onClick = { tab=3 }, icon={ Icon(Icons.Default.Language, null) }, label={ Text("Сайт") })
                NavigationBarItem(selected = tab == 4, onClick = { tab=4 }, icon={ Icon(Icons.Default.Share, null) }, label={ Text("Соцсети") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Surface(shape=RoundedCornerShape(14.dp), color=Accent.copy(alpha=.14f), modifier=Modifier.size(48.dp)) {
                        Box(contentAlignment=Alignment.Center) { Icon(Icons.Default.TravelExplore, null, tint=Accent, modifier=Modifier.size(29.dp)) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("OPENSCOPE", fontSize=23.sp, fontWeight=FontWeight.Black, letterSpacing=2.sp)
                        Text("OSINT WORKSPACE  •  ANDROID", color=Muted, fontSize=10.sp, letterSpacing=1.2.sp)
                    }
                }
                Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("Новый поиск", fontSize=20.sp, fontWeight=FontWeight.Bold)
                        Text(when(tab) { 0 -> "Проверка публичных страниц по никнейму"; 1 -> "Синтаксис email и DNS MX домена"; 2 -> "Разбор номера по библиотеке телефонных планов"; 3 -> "DNS, RDAP и публичная геоинформация IP"; else -> "Открытие публичных профилей для ручного анализа" }, color=Muted, fontSize=13.sp)
                        OutlinedTextField(value=query, onValueChange={query=it; error=""}, modifier=Modifier.fillMaxWidth(), placeholder={Text(hint)}, singleLine=true, shape=RoundedCornerShape(14.dp), colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Accent, unfocusedBorderColor=Muted.copy(alpha=.4f)))
                        if (tab == 2) {
                            OutlinedTextField(value=region, onValueChange={region=it.take(2).uppercase()}, label={Text("Регион по умолчанию (например RU, US)")}, singleLine=true, modifier=Modifier.fillMaxWidth())
                        }
                        if (tab == 4) {
                            Text("Быстрые ссылки", color=Muted, fontSize=12.sp)
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                listOf("Instagram" to "https://www.instagram.com/", "TikTok" to "https://www.tiktok.com/", "X" to "https://x.com/").forEach { (name,url) ->
                                    OutlinedButton(onClick={context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))}) { Text(name) }
                                }
                            }
                        } else {
                            Button(onClick={
                                if (query.isBlank()) { error="Введите данные для поиска"; return@Button }
                                busy=true; error=""
                                scope.launch {
                                    try {
                                        val findings = withContext(Dispatchers.IO) {
                                            when(tab) {
                                                0 -> usernameLookup(query)
                                                1 -> emailLookup(query)
                                                2 -> phoneLookup(query, region)
                                                else -> domainLookup(query)
                                            }
                                        }
                                        report=Report(when(tab){0->"Поиск по никнейму: $query";1->"Проверка email: $query";2->"Проверка телефона: $query";else->"Анализ домена: $query"}, findings)
                                    } catch(e: Exception) { error=e.message ?: "Не удалось выполнить поиск" }
                                    finally { busy=false }
                                }
                            }, modifier=Modifier.fillMaxWidth(), enabled=!busy, shape=RoundedCornerShape(14.dp)) {
                                if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth=2.dp, color=Bg)
                                else { Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("Запустить анализ") }
                            }
                        }
                        if (error.isNotBlank()) Text(error, color=Color(0xFFFF8B8B), fontSize=13.sp)
                    }
                }
                report?.let { r ->
                    Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween, modifier=Modifier.fillMaxWidth()) {
                        Column {
                            Text("Результаты", fontSize=20.sp, fontWeight=FontWeight.Bold)
                            Text("${r.findings.size} наблюдений • ${r.created}", color=Muted, fontSize=11.sp)
                        }
                        OutlinedButton(onClick={ shareReport(context, r) }) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(5.dp)); Text("Экспорт") }
                    }
                    r.findings.forEach { f ->
                        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(15.dp)) {
                            Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment=Alignment.CenterVertically) {
                                    Text(f.title, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                                    Text(f.status, color=when(f.status){"OK"->Accent;"WARN"->Color(0xFFFFC66D);"CHECK"->Color(0xFF9BC7FF);else->Muted}, fontSize=10.sp, fontWeight=FontWeight.Bold)
                                }
                                Text(f.detail, color=Muted, fontSize=13.sp)
                            }
                        }
                    }
                }
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF192A35)), shape=RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        Text("Ответственное использование", color=Accent, fontWeight=FontWeight.Bold)
                        Text("OpenScope работает с общедоступными веб-страницами и публичными справочными API. Результаты могут быть неполными или ошибочными. Не используйте для преследования, доксинга, обхода доступа или принятия решений о человеке. Не вводите чужие чувствительные данные без законного основания.", color=Muted, fontSize=12.sp)
                    }
                }
            }
        }
    }
}

private fun shareReport(context: android.content.Context, report: Report) {
    val text = buildString {
        appendLine("OpenScope OSINT — ${report.heading}")
        appendLine("Создано: ${report.created}")
        appendLine()
        report.findings.forEach {
            appendLine("[${it.status}] ${it.title}")
            appendLine(it.detail)
            appendLine()
        }
        appendLine("Примечание: результаты из открытых источников не являются подтверждением личности или достоверности данных.")
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "OpenScope OSINT report")
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "Экспорт отчёта"))
}
